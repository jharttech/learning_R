#' Plot ticket counts by category
#' 
#' @param data_file A string path to a CSV containing a `category` column.
#' @param output A string path and file name of the plot to be created. Default is "tickets_by_category.png". 
#' @import ggplot2
#' @importFrom tibble as_tibble
#' 
#' @return Creates a plot of ticket counts grouped on the x axis as the ticket categories
#' 
#' @examples
#' \dontrun{
#' # Create a plot from the provided data_file in the default output location.
#' spicket_graph("testdata/Sample_data.csv")
#' 
#' # Create a plot from the provided data_file with a custom location and filename.
#' spicket_graph("testdata/Sample_data.csv", "/home/user/Documents/category_graph.png")
#' }
#' 
#' @export
spicket_graph <- function(data_file, output = "tickets_by_category.png") {
  
  # Read the spiceworks report
  tickets <- read.csv(data_file)
  cat_counts <- table(tickets$category)
  
  # Convert the cat_counts table to a tibble
  ticket_tibb <- as_tibble(cat_counts, .name_repair = "minimal")
  # Rename the columns for easier plotting
  colnames(ticket_tibb) <- c("Category", "Tickets")
  # create the visualization from the tibble using ggplot()
  p <- ggplot(
    ticket_tibb,
    # Set which columns go to which axis
    aes(x = Category, y = Tickets)
  ) + 
    # Set the graph type and colors
    geom_col(
      color = "black",
      fill = "maroon",
    ) +
    # Set the y scale
    scale_y_continuous(
      breaks = seq(0,20, by = 1)
    ) +
    # Set the horizontal line properties
    geom_hline(
      linetype = 3,
      linewidth = .10,
      yintercept = seq(0, 20, by = 1)
    ) +
    # Set the theme
    theme_dark() +
    # Fine tune the theme and set the category names to 45 degrees
    theme(axis.text.x = element_text(angle = 45, hjust = 1,))
  # Save the plot/graph into either the users desired location and filename
  # or using the default of ./tickets_by_category.png
  ggsave(output, plot = p)
}
