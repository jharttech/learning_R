#' Count ticket number for each assignee from a CSV exported from Spiceworks Ticket System
#' 
#' This function reads a CSV file from a Spiceworks Ticket System export and counts
#' the number of tickets for each person listed in a column named 'assignee'.

#' @param data_file A string path to a CSV file containing a `assignee` column.
#' 
#' @return Counts tickets that were assigned to each assignee.
#' 
#' @examples
#' \dontrun{
#' # Count tickets for each assignee
#' spicket_tech("testdata/Sample_data.csv")
#' }
#' 
#' @export
spicket_tech <- function(data_file) {
  tickets <- read.csv(data_file)
  # Count tickets for each assignee
  tech_counts <- table(tickets$assignee)
  print(tech_counts)
}
