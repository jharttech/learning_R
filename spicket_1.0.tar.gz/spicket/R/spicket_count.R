#' Counts the number of tickets in a Spiceworks Ticket system report CSV.
#' 
#' This function simply counts the number of tickets in a report exported from Spiceworks
#' Ticket System.
#' 
#' @param data_file A string path to a CSV file with ticket data
#' 
#' @return Counts the number of tickets in the data_file if one is provided.
#' 
#' @examples
#' \dontrun{
#' # Count the number of tickets in the data_file
#' spicket_count("testdata/Sample_data.csv")
#' }
#' 
#' @export
spicket_count <- function(data_file) {
  tickets <- read.csv(data_file)
  return(nrow(tickets))
}
