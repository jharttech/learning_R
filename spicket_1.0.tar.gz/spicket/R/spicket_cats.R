#' Count tickets by category from a CSV file exported from Spiceworks Ticket System
#' 
#' This function reads a CSV file containing ticket data from Spiceworks, and
#' counts the number of tickets in a specific category. If 'all' is used as a
#' category then a count for all categories is returned.
#' 
#' @param data_file A string path to a CSV file containing a `category` column.
#' @param cats A string specifying the category to count (case-insensitive). Use "all" to return all categories.
#' 
#' @return If a specific category is provided, the function returns an integer for that category.
#' If "all" is specified then the function returns a named vector with counts for each category.
#' 
#' @examples
#' \dontrun{
#' # Count "hardware" tickets
#' spicket_cats("testdata/Sample_data.csv", "hardware")
#' 
#' # Get all category counts
#' spicket_cats("testdata/Sample_data.csv", "all")
#' }
#' 
#' 
#' @export
spicket_cats <- function(data_file, cats) {
  # Read the spiceworks report
  tickets <- read.csv(data_file)
  # Change the cats argument to lowercase for sanity
  cats <- tolower(cats)
  # Check to see if the cats argument is `all`
  if(cats == "all"){
    cat_counts <- table(tolower(tickets$category))
    result <- (cat_counts)
  }
  else {
    # Count the number of tickets for desired category, change the
    # categories to lowercase for sanity
    cat_counts <- table(tolower(tickets$category))
    # Return just the number of tickets for desired category
    result <- (as.numeric(cat_counts[cats]))
  }
  return(result)
}
