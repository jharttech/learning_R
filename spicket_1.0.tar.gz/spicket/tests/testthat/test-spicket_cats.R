test_that("`spicket_cats` totals specific category of tickets", {
  # Test to see if hardware count is correct
  expect_equal(spicket_cats("testdata/Sample_data.csv","hardware"), 2)
  # Test to see if chromebook count is correct
  expect_equal(spicket_cats("testdata/Sample_data.csv","Chromebook"), 4)
  # Test to see if a category that does not exist is handled correctly, using NA_integer_ because the table in the function should return NA as
})
test_that("spicket_cats throws an error with missing argument", {
  # Test to see if missing cats returns and error
  expect_error(spicket_cats("testdata/Sample_data.csv"), regexp = "missing")
})
test_that("spicket_cats fails if a category that does not exist is specified", {
  # Test to see if using a category that does not exist returns NA with a type of integer
  expect_equal(spicket_cats("testdata/Sample_data.csv", "pudding"),NA_integer_)
})
  