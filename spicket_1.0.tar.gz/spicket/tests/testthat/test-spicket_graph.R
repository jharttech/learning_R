test_that("spicket_graph() creates a PNG", {
  png_file <- "tickets_by_category.png"
  
  # If the test png exists remove it first
  if (file.exists(png_file)){
    file.remove(png_file)
  }
  
  # run the spicket_graph function with data_file argument
  spicket_graph("testdata/Sample_data.csv")
  # This tests to see if the test png was created
  expect_true(file.exists(png_file))
  # Remove the test png once test is complete
  file.remove(png_file)
})