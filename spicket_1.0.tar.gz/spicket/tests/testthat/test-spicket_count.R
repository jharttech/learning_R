test_that("`spicket_count` totals all tickets", {
  # Test to see if sample data file counts tickets correctly
  expect_equal(spicket_count("testdata/Sample_data.csv"), 19)
})
test_that("`spicket_count` throws error when missing an argument", {
  # Test to see if an error is thrown when the data_file argument is missing
  expect_error(spicket_cats("testdata/Sample_data.csv"), regexp = "missing")
})