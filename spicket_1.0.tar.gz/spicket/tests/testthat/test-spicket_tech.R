test_that("spicket_tech prints assignee table", {
  # capture the output which should be a table
  output <- capture.output(spicket_tech("testdata/Sample_data.csv"))
  # check to see if the table contained in the output contains the term Tech
  expect_true(any(grepl("Tech", output, ignore.case = TRUE)))
  # Check to see if the table contained in the output contains a numeric value
  # for ticket counts
  expect_true(any(grepl("\\d+", output)))
})