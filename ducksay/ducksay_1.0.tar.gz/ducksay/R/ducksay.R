ducksay <- function(){
  paste(
    "hello, world",
    ">(. )__/",
    " (____/",
    sep = "\n"
  )
}